// import logo from './logo.svg';
import './style.css';
import Product from './Comp/Product';
import Navbar from './Comp/Navbar';
function App() {
  return (
  <>
  <Navbar/>
  <Product/>
  
  </>
  );
}

export default App;
