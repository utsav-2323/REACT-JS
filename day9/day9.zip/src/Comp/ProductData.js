import img1 from './img/1.jpg'
import img2 from './img/men-2.jpg'
import img3 from './img/men-3.jpg'
import img4 from './img/men-4.jpg'
import img5 from './img/men-5.jpg'
import img6 from './img/men-6.jpg'
import img7 from './img/men-7.jpg'
import img8 from './img/men-8.jpg'
import img9 from './img/men-9.jpg'
import img10 from './img/men-10.jpg'
import img11 from './img/men-11.jpg'
import img12 from './img/men-12.jpg'

const ProductData =[
    {
        id: 1,
        Title: 'product 1',
        img: `${img1}`,
        price: 200,
        des: " Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam sapiente officiis laboriosam ab consectetur commodi blanditiis sequi sed quibusdam, atque impedit repellat debitis repudiandae. Explicabo nemo impedit vitae architecto officiis.",
    },


    {
        id: 2,
        Title: 'product 2',
        img: `${img2}`,
        price: 300,
        des: " Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam sapiente officiis laboriosam ab consectetur commodi blanditiis sequi sed quibusdam, atque impedit repellat debitis repudiandae. Explicabo nemo impedit vitae architecto officiis.",
    },

    {
        id: 3,
        Title: 'product 3',
        img: `${img3}`,
        price: 250,
        des: " Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam sapiente officiis laboriosam ab consectetur commodi blanditiis sequi sed quibusdam, atque impedit repellat debitis repudiandae. Explicabo nemo impedit vitae architecto officiis.",
    },

    {
        id: 4,
        Title: 'product 4',
        img: `${img4}`,
        price: 100,
        des: " Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam sapiente officiis laboriosam ab consectetur commodi blanditiis sequi sed quibusdam, atque impedit repellat debitis repudiandae. Explicabo nemo impedit vitae architecto officiis.",
    },

    {
        id: 5,
        Title: 'product 5',
        img: `${img5}`,
        price: 290,
        des: " Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam sapiente officiis laboriosam ab consectetur commodi blanditiis sequi sed quibusdam, atque impedit repellat debitis repudiandae. Explicabo nemo impedit vitae architecto officiis.",
    },

    {
        id: 6,
        Title: 'product 6',
        img: `${img6}`,
        price: 400,
        des: " Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam sapiente officiis laboriosam ab consectetur commodi blanditiis sequi sed quibusdam, atque impedit repellat debitis repudiandae. Explicabo nemo impedit vitae architecto officiis.",
    },

    {
        id: 7,
        Title: 'product 7',
        img: `${img7}`,
        price: 350,
        des: " Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam sapiente officiis laboriosam ab consectetur commodi blanditiis sequi sed quibusdam, atque impedit repellat debitis repudiandae. Explicabo nemo impedit vitae architecto officiis.",
    },

    {
        id: 8,
        Title: 'product 8',
        img: `${img8}`,
        price: 200,
        des: " Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam sapiente officiis laboriosam ab consectetur commodi blanditiis sequi sed quibusdam, atque impedit repellat debitis repudiandae. Explicabo nemo impedit vitae architecto officiis.",
    },

    {
        id: 9,
        Title: 'product 9',
        img: `${img9}`,
        price: 180,
        des: " Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam sapiente officiis laboriosam ab consectetur commodi blanditiis sequi sed quibusdam, atque impedit repellat debitis repudiandae. Explicabo nemo impedit vitae architecto officiis.",
    },

    {
        id: 10,
        Title: 'product 10',
        img: `${img10}`,
        price: 220,
        des: " Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam sapiente officiis laboriosam ab consectetur commodi blanditiis sequi sed quibusdam, atque impedit repellat debitis repudiandae. Explicabo nemo impedit vitae architecto officiis.",
    },

    {
        id: 11,
        Title: 'product 11',
        img: `${img11}`,
        price: 260,
        des: " Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam sapiente officiis laboriosam ab consectetur commodi blanditiis sequi sed quibusdam, atque impedit repellat debitis repudiandae. Explicabo nemo impedit vitae architecto officiis.",
    },


    {
        id: 12,
        Title: 'product 12',
        img: `${img12}`,
        price: 500,
        des: " Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam sapiente officiis laboriosam ab consectetur commodi blanditiis sequi sed quibusdam, atque impedit repellat debitis repudiandae. Explicabo nemo impedit vitae architecto officiis.",
    },
]
export default ProductData;