import './App.css'
import React, { useState } from 'react'

function App() {
  const [Product, setProduct] = useState("");
  const [cat, setCat] = useState("");
  const [fullname,setfullname] =useState("");
  const [error,seterror] =useState("");
  const [email,setemail] =useState("");
  const [error2,seterror2] =useState("");
  const [error3,seterror3] =useState("");
  const [phonenumber,setphonenumber] =useState("");



  const handlesubmit = (e) => {
    setCat(e.target.value);
    e.preventDefault();
    if(fullname == ""){
      seterror("input feild in empty");
    }else{
      seterror("");
    }

    if(!email.includes("@")){
      seterror2("email is not valid")
    }else{
      seterror2("")
    }
    
  };

  return ( 
    <>
      <div className='box'onSubmit={handlesubmit}>
        <div className="main">
          <form>
            <div className="hending" >
              <h1>Product Detail</h1>
            </div>
            <div className="a-1" >
              <label>Full Name</label>
              <input type="text" placeholder='Full Name' onChange={(e)=> setfullname(e.target.value)} />
          {error && <p>{error}</p>}
            </div>
            <div className="a-1">
              <label>E-mail</label>
              <input type="text" placeholder='E-mail'  onChange={(e)=> setemail(e.target.value)}/>
          {error && <p>{error2}</p>}
            </div>
            <div className="a-1">
              <label>Phone Number</label>
              <input type="text" placeholder='Phone Number'  onChange={(e)=> setphonenumber(e.target.value)} />
          {error && <p>{error3}</p>}
            </div>

            <div className="se">
              <select value={cat} onChange={handlesubmit}>
                <option value="" disabled>Select Product</option>
                <option value="watch">laptop</option>
                <option value="mobile">mobile</option>
                <option value="headphone">AC</option>
              </select>
            </div>
            <div className="d-1">
              <input 
                type="text" 
                placeholder='Enter Product Name' 
                onChange={(e) => setProduct(e.target.value)}  
              />

              {
                cat === "watch" &&
                <>
                  <input type="text" placeholder='Enter Warranty'/>
                  <input type="text" placeholder='Enter Price'/>
                </>
              }

              {
                cat === "mobile" &&
                <>
                  <input type="text" placeholder='Enter Warranty'/>
                  <input type="text" placeholder='Enter Price'/>
                </>
              }

              {
                cat === "headphone" &&
                <>
                  <input type="text" placeholder='Enter Warranty'/>
                  <input type="text" placeholder='Enter Price'/>
                </>
              }
            </div>
            <div className="bu">
              <input type="submit" />
            </div>
          </form>
        </div>
      </div>
    </>
  )
}

export default App
